package com.student.management.service;

import java.util.List;

import com.student.management.entity.Student;

public interface StudentService {

	
	
     List<Student> getAllStudents();
	
	Student saveStudent(Student student);
	
	Student getStudentById(int id);
	
	Student updateStudent(Student student);
	
	void deleteStudentById(int id);

	//Student getStudentById1(int id);

}
